´´´
kommatipara/
├─ client_data/
├─ src/
│  ├─ main.py
├─ README.md
´´´
